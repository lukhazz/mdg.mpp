
$.fullCalendar.locale("gl", {
	buttonText: {
		month: "Mes",
		week: "Semana",
		day: "Día",
		list: "Axenda"
	},
	allDayHtml: "Todo<br/>o día",
	eventLimitText: "máis",
	noEventsMessage: "Non hai eventos para amosar"
});
