
$.fullCalendar.locale("is", {
	buttonText: {
		month: "Mánuður",
		week: "Vika",
		day: "Dagur",
		list: "Dagskrá"
	},
	allDayHtml: "Allan<br/>daginn",
	eventLimitText: "meira",
	noEventsMessage: "Engir viðburðir til að sýna"
});
