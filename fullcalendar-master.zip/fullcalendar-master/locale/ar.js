
$.fullCalendar.locale("ar", {
	buttonText: {
		month: "شهر",
		week: "أسبوع",
		day: "يوم",
		list: "أجندة"
	},
	allDayText: "اليوم كله",
	eventLimitText: "أخرى",
	noEventsMessage: "أي أحداث لعرض"
});
