
$.fullCalendar.locale("lt", {
	buttonText: {
		month: "Mėnuo",
		week: "Savaitė",
		day: "Diena",
		list: "Darbotvarkė"
	},
	allDayText: "Visą dieną",
	eventLimitText: "daugiau",
	noEventsMessage: "Nėra įvykių rodyti"
});
