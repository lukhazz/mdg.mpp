
$.fullCalendar.locale("ko", {
	buttonText: {
		month: "월",
		week: "주",
		day: "일",
		list: "일정목록"
	},
	allDayText: "종일",
	eventLimitText: "개",
	noEventsMessage: "일정이 표시 없습니다"
});
