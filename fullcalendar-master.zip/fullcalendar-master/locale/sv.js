
$.fullCalendar.locale("sv", {
	buttonText: {
		month: "Månad",
		week: "Vecka",
		day: "Dag",
		list: "Program"
	},
	allDayText: "Heldag",
	eventLimitText: "till",
	noEventsMessage: "Inga händelser att visa"
});
