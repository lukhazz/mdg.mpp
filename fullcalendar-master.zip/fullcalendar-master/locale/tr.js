
$.fullCalendar.locale("tr", {
	buttonText: {
		next: "ileri", // override JQUI's, which has a non-closing HTML entity in it
		month: "Ay",
		week: "Hafta",
		day: "Gün",
		list: "Ajanda"
	},
	allDayText: "Tüm gün",
	eventLimitText: "daha fazla",
	noEventsMessage: "Herhangi bir etkinlik görüntülemek için"
});
